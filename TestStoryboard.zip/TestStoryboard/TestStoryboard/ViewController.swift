//
//  ViewController.swift
//  TestStoryboard
//
//  Created by Kamila Young on 27.09.22.
//

import UIKit
import VungleSDK

class ViewController: UIViewController, VungleSDKDelegate {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        // Do any additional setup after loading the view.
        func start(withAppId appID: String) throws {
        }
        
        let appID = "632860d3167642f894b5a284";
        var placementIDsArray:Array<String> = ["<INTERST-3362874>"];
        var sdk:VungleSDK = VungleSDK.shared()
        
        
        do {
            try sdk.start(withAppId: appID);
        } catch let error as NSError {
            print("Error while starting VungleSDK : \(error.domain)")
            return;
        }
        //following method is called when the SDK has initialized successfully
        func vungleSDKDidInitialize() {
        }
        func startVungle() {
            
            //You can receive callbacks from the SDK with VungleSDKDelegate.
            // Attach
            sdk.delegate = ["<yourDelegateInstance>"] as? VungleSDKDelegate
            
            // Detach
            sdk.delegate = nil
            
            
            return;
        }
        //The following method is called when the SDK is about to play a video ad. This is a great place to pause gameplay, sound effects, animations, etc.
        func vungleWillShowAd(forPlacementID placementID: String?) {
        }
        //The following method is called when the SDK has just begun to play a video ad:
        func vungleDidShowAd(forPlacementID placementID: String?) {do {
            print("vungleAdPlayabilityUpdate called")
        }
           
            //The following method is called when the SDK has changed ad availability status.
            func vungleAdPlayabilityUpdate(_ isAdPlayable: Bool, placementID: String?, error: Error?) {
            }
            //The following method is called when the user clicks the Vungle ad. At this point, it is recommended to track click event.
            func vungleTrackClick(forPlacementID placementID: String?) {
            }
            //The following method is called when the user taps the Vungle ad which will cause them to leave the current application (e.g the ad action opens the iTunes store, Mobile Safari, etc).
            func vungleWillLeaveApplication(forPlacementID placementID: String?) {
            }
            //The following method is called when the user should be rewarded for watching a Rewarded Video ad. At this point, it's recommended to reward the user.
            func vungleRewardUser(forPlacementID placementID: String?) {
            }
            //The following method is called when the SDK fails to initialize. If this happens, restart the Vungle SDK.
            func vungleSDKFailedToInitializeWithError(_ error: Error?) {
            }
            //The following method is called when the ad is first rendered on device. Please use this callback to track impressions.
            func vungleAdViewed(forPlacement placementID: String?) {
            }
            //To load an ad, call the loadPlacementWithID method
            func loadPlacement(withID placementID: String?) throws {
            }
            
            do {
                try sdk.loadPlacement(withID: "<INTERST-3362874>")
            } catch let error as NSError {
                print("Unable to load placement with reference ID :\("<INTERST-3362874>"), Error: \(error)")
                return
            }
            //After you make sure that an ad is ready for a placement, you can play the ad with the following method:
            func playAd(_ controller: UIViewController?, options: [AnyHashable : Any]?, placementID: String?) throws {
            }
            var sdk:VungleSDK = VungleSDK.shared()
            do {
                try sdk.playAd(self, options: nil, placementID: "<INTERST-3362874>")
            } catch let error as NSError {
                print("Error encountered playing ad: + \(error)");
            }
        }
    }
    
    
    
    
}
